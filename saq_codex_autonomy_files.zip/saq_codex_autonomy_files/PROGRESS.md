# PROGRESS.md

This file is the running log for autonomous Codex work on `saq-boundary-audit`.

Codex must update this file during each session. Prefer factual, command-backed notes over speculation.

## Current Baseline As Of 2026-07-07

### Research Direction

The active direction is query-unaware SAQ follow-up work. The current method story is a fixed policy around SAQ's default segment plan:

1. classify the SAQ default plan shape;
2. generate local default-neighborhood candidates;
3. score candidates with data-only boundary-risk and speed proxies;
4. promote conservative/frontier-like candidates;
5. reject candidates that trade too much recall for speed;
6. abstain when no meaningful local neighborhood exists.

### Current Evidence

| Setting | Current decision | Plan | Measured interpretation |
|---|---:|---|---|
| GIST full K4096 B=3 | promote | `64:8,320:5,320:2,256:0` | positive after 1-bit fix; +0.00159 R@100, 1.1119x QPS at np800 |
| GIST full K4096 B=4 | promote | `128:9,320:5,320:3,192:0` | strongest QPS-positive GIST case; +0.00077 R@100, 1.1948x QPS at np800 |
| GIST full K4096 B=5 | promote | `128:9,128:7,320:5,320:3,64:0` | positive high-budget holdout; +0.00028 R@100, 1.0793x QPS at np800 |
| CIFAR60K B=3 | promote | `128:6,64:4,192:2,128:0` | small positive; +0.0004 R@10, 1.0761x QPS at np200 |
| CIFAR60K B=4 | promote | `128:7,256:4,128:0` | small positive; +0.0004 R@10, 1.0745x QPS at np200 |
| CIFAR60K B=5 | promote | `128:8,64:6,256:4,64:0` | small positive; +0.0008 R@10, 1.0609x QPS at np200 |
| DEEP100K B=4 | reject | `128:4,128:3` | QPS improves but recall drops too much; -0.02757 R@100, 1.0893x QPS at np200 |
| DEEP100K B=5 | reject | `128:5,128:4` | QPS improves but recall drops too much; -0.01429 R@100, 1.1037x QPS at np200 |
| audio B=4 | abstain | none | single-uniform default; scan also abstains at B=3/B=5 |
| word2vec100K B=4 | abstain | none | single-uniform default; scan also abstains at B=3/B=5 |

Source of this baseline: `docs/saq_fixed_policy_method_spec_2026_07_07.md` and `docs/saq_fixed_policy_clean_validation_table_2026_07_07.csv`.

### Known Implementation/Method Notes

- `script/run_default_neighborhood_cross_dataset.py` connects candidate generation, scoring, index build, recall comparison, and QPS measurement.
- `script/run_fixed_policy_matrix.py` is the end-to-end matrix runner for the fixed-policy evidence table.
- `script/report_fixed_policy_validation.py` regenerates the clean validation table/report from summary outputs and can compare against the checked-in expected CSV.
- `script/sweep_data_boundary_pairs.py` contains planner v3 and conservative role fields.
- GIST B=3 required a minimal 1-bit CAQ segment fix touching:
  - `saqlib/quantization/caq/caq_encoder.hpp`
  - `saqlib/quantization/cluster_packer.hpp`
- All measured recall/QPS claims must use `-searcher_safe_block_min_mode=2`.

## Session Log Template

Copy this block for each autonomous run.

```md
## Session YYYY-MM-DD HH:MM local

### Goal

### Starting state
- Branch:
- `git status --short`:
- Files read:

### Hypothesis / plan

### Commands run

```bash
# paste exact commands here
```

### Files changed

### Artifacts produced

### Result

### Interpretation

### Problems / blockers

### Next action
```

## Session 2026-07-07 Initial External Setup

### Goal

Create autonomous-iteration control files for future Codex sessions based on the current public `saq-boundary-audit` branch state.

### Starting state

This file was generated outside the repository from the public GitHub branch. It has not been validated by running local repository commands.

### Files read remotely

- `AGENTS.md`
- `codex_handoff.md`
- `README.md`
- `docs/saq_fixed_policy_method_spec_2026_07_07.md`
- `docs/saq_fixed_policy_clean_validation_table_2026_07_07.csv`
- `docs/saq_stage_synthesis_v3_conservative_2026_07_06.md`
- `docs/saq_gist_full_k4096_B3_after_1bit_fix_2026_07_07.md`
- `docs/saq_cross_dataset_default_neighborhood_validation_2026_07_06.md`
- `docs/saq_default_neighborhood_applicability_scan_2026_07_06.md`
- `docs/saq_gist_sample100k_B5_v3_conservative_guard_2026_07_06.md`

### Result

Prepared `AGENTS.md`, `TASK.md`, `PROGRESS.md`, `EXPERIMENTS.md`, and `RESULTS.md` for repo-local use.

### Next action

Place these files at the repository root, inspect the diff, then start Codex with the prompt in `TASK.md` or with:

```bash
codex exec --sandbox workspace-write --ask-for-approval never --cd . - < TASK.md
```
